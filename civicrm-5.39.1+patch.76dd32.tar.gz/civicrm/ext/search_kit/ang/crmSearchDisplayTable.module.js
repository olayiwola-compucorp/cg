(function(angular, $, _) {
  "use strict";

  // Declare module
  angular.module('crmSearchDisplayTable', CRM.angRequires('crmSearchDisplayTable'));

})(angular, CRM.$, CRM._);
