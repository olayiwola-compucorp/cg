<?php
namespace Civi\OAuth;

class OAuthException extends \CRM_Core_Exception {

}
