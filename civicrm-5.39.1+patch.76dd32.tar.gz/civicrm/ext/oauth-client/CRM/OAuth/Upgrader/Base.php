<?php

/**
 * Base class which provides helpers to execute upgrade logic
 */
class CRM_OAuth_Upgrader_Base extends CRM_Extension_Upgrader_Base {
}
