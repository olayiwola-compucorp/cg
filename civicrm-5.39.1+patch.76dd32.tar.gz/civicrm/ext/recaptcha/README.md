# recaptcha

Core extension to extract the reCAPTCHA functionality from CiviCRM core so it can be disabled/replaced.

The extension is licensed under [AGPL-3.0](LICENSE.txt).
