<?php
/** @deprecated */
function civicrmVersion( ) {
  return array( 'version'  => '5.39.1',
                'cms'      => 'Drupal',
                'revision' => '' );
}

